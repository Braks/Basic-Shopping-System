﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.Infrastructure;
using System.Globalization;
using System.Web.Mvc;
using System.Web.Security;
using System.IO;


namespace basic_shopping_system.Models
{
    public class checkuser
    {
        [Key]
        public int Id { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        public string email { get; set; }
        public string password { get; set; }
        public string datecreated { get; set; }
        public string role { get; set; }

    }
    public class products
    {
        [Key]
        public int Id { get; set; }
        public string productname { get; set; }
        public decimal price { get; set; }
        public decimal discount { get; set; }
        public decimal discountprice { get; set; }
        public decimal totalamount { get; set; }
        public string currency { get; set; }
    }

    public class topuptable
    {
        [Key]
        public int Id { get; set; }
        public string useremail { get; set; }
        public decimal topupamount { get; set; }
        public decimal balance { get; set; }
        public string currency { get; set; }
        [DisplayFormat(DataFormatString = "{0:d}", ApplyFormatInEditMode = true)]
        public DateTime topupdate { get; set; }
    
    }

    public class transactions
    {
        [Key]
        public int Id { get; set; }
        public string useremail { get; set; }
        public string product { get; set; }
        public decimal totalamount { get; set; }
        public string currency { get; set; }
        [DisplayFormat(DataFormatString = "{0:d}", ApplyFormatInEditMode = true)]
        public DateTime transactiondate { get; set; }
        
    }
    public class SystemContext : DbContext
    {
        public DbSet<checkuser> REGISTRATIONS { get; set; }
        public DbSet<products> PRODUCTS { get; set; }
        public DbSet<topuptable> TOPUPTABLE { get; set; }
        public DbSet<transactions> TRANSACTIONS{ get; set; }
       
    }

}