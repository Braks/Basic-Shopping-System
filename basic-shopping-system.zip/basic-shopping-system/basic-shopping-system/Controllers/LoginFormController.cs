﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using basic_shopping_system.Models;
using System.Web.SessionState;

namespace basic_shopping_system.Controllers
{
    public class LoginFormController : Controller
    {
        private SystemContext db = new SystemContext();

        //
        // GET: /LoginForm/

        public ActionResult Index()
        {
             if (!String.IsNullOrEmpty(Convert.ToString(Session["buyproductssession"])))
             {
            //Session["buyproductssession"] = value;
            return View(db.REGISTRATIONS.ToList());
             }
             else
             {
                 return RedirectToAction("Details");
             }
        }

        //
        

        //
        // GET: /LoginForm/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /LoginForm/Create

        
        public ActionResult Create(checkuser checkuser)
        {
            if (ModelState.IsValid)
            {
                db.REGISTRATIONS.Add(checkuser);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(checkuser);
        }


        [HttpPost]
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult BUY(FormCollection colect)
        {
            ViewBag.Info = HttpContext.Session["buyproductssession"];
            string value = colect["username"];
            Session["buyproductssession"] = value;
            return View();
        }
        public ActionResult BUY()
        {
            
            return View();
        }
       
        //
        // GET: /LoginForm/Edit/5

        public ActionResult Edit(int id = 0)
        {
            checkuser checkuser = db.REGISTRATIONS.Find(id);
            if (checkuser == null)
            {
                return HttpNotFound();
            }
            return View(checkuser);
        }

        //
        // POST: /LoginForm/Edit/5

        [HttpPost]
        public ActionResult Edit(checkuser checkuser)
        {
            if (ModelState.IsValid)
            {
                db.Entry(checkuser).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(checkuser);
        }

        //
        // GET: /LoginForm/Delete/5

        public ActionResult Delete(int id = 0)
        {
            checkuser checkuser = db.REGISTRATIONS.Find(id);
            if (checkuser == null)
            {
                return HttpNotFound();
            }
            return View(checkuser);
        }

        //
        // POST: /LoginForm/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            checkuser checkuser = db.REGISTRATIONS.Find(id);
            db.REGISTRATIONS.Remove(checkuser);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }


    
        public ActionResult Details()
        {
            return View();
        }

        //Redirect to loginform
        public ActionResult PartialDetails()
        {
            return RedirectToAction("Details");
            // return View();
        }
        // GET: /LoginForm/Details/5
        [HttpPost]
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Details(FormCollection colect)
        {

            string value = colect["username"];
            string value2 = colect["password"];
            //checkuser checkuser = db.REGISTRATIONS.Find(id);
            //if (checkuser == null)
            //{
            //    return HttpNotFound();
            //}
            //return View(checkuser);
            try
            {
                var log = from w in db.REGISTRATIONS
                          where w.email == value && w.password == value2 
                          select w;
                if(log.Count()>0)
                
                {
                    
                        Session["buyproductssession"] = value;
                        return RedirectToAction("Index", "Products");
                        //return RedirectToAction("BUY");
                    }
                    
                    else
                    {
                        
                        Response.Write("<script>alert('Wrong UserName or Password')</script>;");
                        return View();
                    }

                //}
            }
            catch (Exception ex)
            {

                Response.Write(ex.Message);
            }
            return View();
        }
        }
    //}
}