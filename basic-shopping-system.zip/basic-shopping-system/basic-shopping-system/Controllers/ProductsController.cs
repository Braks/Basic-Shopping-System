﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using basic_shopping_system.Models;
using System.Web.SessionState;

namespace basic_shopping_system.Controllers
{
    public class ProductsController : Controller
    {
        private SystemContext db = new SystemContext();

        //
        // GET: /Products/
        [HttpPost]
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Index(FormCollection colect)
        {
            ViewBag.Info = HttpContext.Session["buyproductssession"];
            string value = colect["username"];
            Session["buyproductssession"] = value;
            return View(db.PRODUCTS.ToList());
        }
        public ActionResult Index()
        {
                        return View(db.PRODUCTS.ToList());
        }
        //
        // GET: /Products/Details/5

        public ActionResult Details()
        {
            //products products = db.PRODUCTS.Find(id);
            //if (products == null)
            //{
            //    return HttpNotFound();
            //}
            //return View(products);
            return View(db.PRODUCTS.ToList());
        }

        //
        // GET: /Products/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /Products/Create adminlogin

        [HttpPost]
        public ActionResult Create(products products)
        {
            if (!String.IsNullOrEmpty(Convert.ToString(Session["addproductssession"])))
            {
                decimal productprice2 = products.price;
                if (ModelState.IsValid)
                {
                    decimal discount = 0;
                    if (productprice2 < 100)
                    {
                        discount = 0;

                        products.discountprice = discount;
                        products.totalamount = products.price;
                        products.discount = 0;
                        db.PRODUCTS.Add(products);
                        db.SaveChanges();
                        return RedirectToAction("Index");
                    }
                    else if (productprice2 >= 100 && productprice2 < 120)
                    {
                        var f1 = productprice2 * 0.25M;
                        var f2 = productprice2 - f1;
                        products.totalamount = f2;
                        products.discountprice = f2;
                        products.discount = Convert.ToDecimal(0.25);

                        db.PRODUCTS.Add(products);
                        db.SaveChanges();
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        var f1 = productprice2 * 0.50M;
                        var f2 = productprice2 - f1;
                        products.totalamount = f2;
                        products.discountprice = f2;

                        discount = Convert.ToDecimal(0.50);
                        products.discount = Convert.ToDecimal(0.50);
                        db.PRODUCTS.Add(products);
                        db.SaveChanges();
                        return RedirectToAction("Index");
                    }

                    //db.PRODUCTS.Add(products);
                    //db.SaveChanges();
                    //return RedirectToAction("Index");
                } Response.Write("<script>alert('An error occurred. Please varify your data and try again')</script>;");
            }
            Response.Write("<script>alert('Only Administrator can add new products')</script>;");
            //return View(products);
            return RedirectToAction("Index");
        }

        //
        // GET: /Products/Edit/5

        public ActionResult Edit(int id = 0)
        {
            products products = db.PRODUCTS.Find(id);
            if (products == null)
            {
                return HttpNotFound();
            }
            return View(products);
        }

        //
        // POST: /Products/Edit/5

        [HttpPost]
        public ActionResult Edit(products products,transactions buy,topuptable topupmoney)
        {
            if (ModelState.IsValid)
            {

                db.TRANSACTIONS.Add(buy);
                //db.Entry(products).State = EntityState.Modified;
                //buy.useremail = "try@gmail.com";
                buy.useremail = Convert.ToString(Session["buyproductssession"]);

                var conted = from findcount in db.TOPUPTABLE
                             where findcount.useremail ==buy.useremail
                             select findcount;
                foreach (var h in conted)

                    if (h.balance < buy.totalamount)
                    {
                        Response.Write("<script>alert('You do not have enough balance to make the transaction.Please top-up your balance')</script>;");
                        return RedirectToAction("Index");
                    }
                    
                    else
                buy.product = products.productname;
                buy.totalamount = products.totalamount;
                buy.currency = products.currency;
                DateTime todayis = DateTime.Today;
                //var correctdate = todayis.ToString("d");
                buy.transactiondate = todayis;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(products);
        }

        //
        // GET: /Products/Delete/5

        public ActionResult Delete(int id = 0)
        {
            products products = db.PRODUCTS.Find(id);
            if (products == null)
            {
                return HttpNotFound();
            }
            return View(products);
        }

        //
        // POST: /Products/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            products products = db.PRODUCTS.Find(id);
            db.PRODUCTS.Remove(products);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        public ActionResult adminlogin()
        {
            return View();
        }
        public ActionResult signout()
        {
            Session.Clear();
            Response.Cookies.Clear();
            Session.RemoveAll();
                return View();
        }
        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}