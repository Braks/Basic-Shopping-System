﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using basic_shopping_system.Models;
using System.Web.SessionState;

namespace basic_shopping_system.Controllers
{
    public class TopupController : Controller
    {
        private SystemContext db = new SystemContext();

        //
        // GET: /Topup/

        public ActionResult Index()
        {
            return View(db.TOPUPTABLE.ToList());
        }

        //
        // GET: /Topup/Details/5

        public ActionResult Details(int id = 0)
        {
            topuptable topuptable = db.TOPUPTABLE.Find(id);
            if (topuptable == null)
            {
                return HttpNotFound();
            }
            return View(topuptable);
        }

        //
        // GET: /Topup/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /Topup/Create

        [HttpPost]
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Create(topuptable topuptable,FormCollection colect)
        {
            ViewBag.Info = HttpContext.Session["buyproductssession"];
            string value = colect["username"];
            Session["buyproductssession"] = value;
           
            if (ModelState.IsValid)
            {
                var findrecord = from find in db.TOPUPTABLE
                                 where find.useremail == topuptable.useremail
                                 select find;
                if (findrecord.Count() > 0)
                {

                    return RedirectToAction("Index");

                }
                else
                
               
                topuptable.topupdate= DateTime.Now;
                topuptable.useremail = value;
                db.TOPUPTABLE.Add(topuptable);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(topuptable);
        }

        //
        // GET: /Topup/Edit/5

        public ActionResult Edit(int id = 0)
        {
            topuptable topuptable = db.TOPUPTABLE.Find(id);
            if (topuptable == null)
            {
                return HttpNotFound();
            }
            return View(topuptable);
        }

        //
        // POST: /Topup/Edit/5

        [HttpPost]
        public ActionResult Edit(topuptable topuptable)
        {
            if (ModelState.IsValid)
            {
                db.Entry(topuptable).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(topuptable);
        }

        //
        // GET: /Topup/Delete/5

        public ActionResult Delete(int id = 0)
        {
            topuptable topuptable = db.TOPUPTABLE.Find(id);
            if (topuptable == null)
            {
                return HttpNotFound();
            }
            return View(topuptable);
        }

        //
        // POST: /Topup/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            topuptable topuptable = db.TOPUPTABLE.Find(id);
            db.TOPUPTABLE.Remove(topuptable);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}