﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using basic_shopping_system.Models;
using System.Text.RegularExpressions;
using System.Web.SessionState;

namespace basic_shopping_system.Controllers
{
    public class NewuserController : Controller
    {
        private SystemContext db = new SystemContext();

        //
        // GET: /Newuser/

        public ActionResult Index()
        {
            return View(db.REGISTRATIONS.ToList());
        }

        //
        // GET: /Newuser/Details/5

        public ActionResult Details(int id = 0)
        {
            checkuser checkuser = db.REGISTRATIONS.Find(id);
            if (checkuser == null)
            {
                return HttpNotFound();
            }
            return View(checkuser);
        }

        //
        // GET: /Newuser/Create

        public ActionResult Create1()
        {
            return View();
        }

        public ActionResult accountcreated()
        {
            return View();
        }

        //
        // POST: /Newuser/Create

        [HttpPost]
        public ActionResult Create1(checkuser checkuser)
        {
            if (ModelState.IsValid)
            {
                var emailvalidate = checkuser.email;

                DateTime todayis = DateTime.Today;
                var correctdate = todayis.ToString("d");
                checkuser.datecreated = correctdate;
                string mailid = Convert.ToString(emailvalidate);
                Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
                Match match = regex.Match(mailid);
                if (match.Success)
                    try
                    {
                        var findrecord = from find in db.REGISTRATIONS
                                     where find.email == checkuser.email
                                     select find;
                        if (findrecord.Count() > 0)
                       
                        {
                            
                            Response.Write("<script>alert('Error:The user already exists')</script>;");
                           
                        }
                        else

                        {
                            checkuser.role = "defualt";
                            
                        db.REGISTRATIONS.Add(checkuser);
                        db.SaveChanges();
                        Session["buyproductssession"] = checkuser.email;
                        return RedirectToAction("Index", "Products");
                        }

               // {
                       
                    }
                    catch (Exception ex)
                    {
                        Response.Write("<script>alert('Error:Something went wrong. Please valid your data and try again')</script>;");
                    }
                else 
                {
                    return RedirectToAction("wrongemail");
                }
            }

            return View(checkuser);
        }

        //
        // GET: /Newuser/Edit/5

        public ActionResult Edit(int id = 0)
        {
            checkuser checkuser = db.REGISTRATIONS.Find(id);
            if (checkuser == null)
            {
                return HttpNotFound();
            }
            return View(checkuser);
        }

        //
        // POST: /Newuser/Edit/5

        [HttpPost]
        public ActionResult Edit(checkuser checkuser)
        {
            if (ModelState.IsValid)
            {
                db.Entry(checkuser).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(checkuser);
        }

        //
        // GET: /Newuser/Delete/5

        public ActionResult Delete(int id = 0)
        {
            checkuser checkuser = db.REGISTRATIONS.Find(id);
            if (checkuser == null)
            {
                return HttpNotFound();
            }
            return View(checkuser);
        }

        //
        // POST: /Newuser/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            checkuser checkuser = db.REGISTRATIONS.Find(id);
            db.REGISTRATIONS.Remove(checkuser);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}