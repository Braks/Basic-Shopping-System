﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.SessionState;
using basic_shopping_system.Models;

namespace basic_shopping_system.Controllers
{
    public class DataController : Controller
    {
        private SystemContext db = new SystemContext();

        //
        // GET: /Data/

        public JsonResult UserLogin(checkuser d)
        {
            using (SystemContext db2 = new SystemContext())
            {
                var findrecord = from find in db.REGISTRATIONS
                                     where find.email.Equals(d.email) && find.password.Equals(d.password)
                                     select find;
                if (findrecord.Count() > 0)
                {
                    //return View(checkuser);
                    Response.Write("<script>alert('Error:The user already exists')</script>;");
                    //Response.Redirect("Newuser/Index");
                 }
                       
                
               // var user = db2.REGISTRATIONS.Where(a => a.email.Equals(d.email) && a.password.Equals(d.password));
                return new JsonResult { Data = findrecord, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            }
        }

        public ActionResult Index()
        {
            return View(db.REGISTRATIONS.ToList());
        }

        //
        // GET: /Data/Details/5

        public ActionResult Details(int id = 0)
        {
            checkuser checkuser = db.REGISTRATIONS.Find(id);
            if (checkuser == null)
            {
                return HttpNotFound();
            }
            return View(checkuser);
        }

        //
        // GET: /Data/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /Data/Create

        [HttpPost]
        public ActionResult Create(checkuser checkuser)
        {
            if (ModelState.IsValid)
            {
                db.REGISTRATIONS.Add(checkuser);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(checkuser);
        }

        //
        // GET: /Data/Edit/5

        public ActionResult Edit(int id = 0)
        {
            checkuser checkuser = db.REGISTRATIONS.Find(id);
            if (checkuser == null)
            {
                return HttpNotFound();
            }
            return View(checkuser);
        }

        //
        // POST: /Data/Edit/5

        [HttpPost]
        public ActionResult Edit(checkuser checkuser)
        {
            if (ModelState.IsValid)
            {
                db.Entry(checkuser).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(checkuser);
        }

        //
        // GET: /Data/Delete/5

        public ActionResult Delete(int id = 0)
        {
            checkuser checkuser = db.REGISTRATIONS.Find(id);
            if (checkuser == null)
            {
                return HttpNotFound();
            }
            return View(checkuser);
        }

        //
        // POST: /Data/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            checkuser checkuser = db.REGISTRATIONS.Find(id);
            db.REGISTRATIONS.Remove(checkuser);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}